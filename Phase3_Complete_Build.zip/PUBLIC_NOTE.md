This project includes a /public directory so Vercel default output directory works for static deployments.
